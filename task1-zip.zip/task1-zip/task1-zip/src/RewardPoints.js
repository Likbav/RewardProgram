import React, { useState, useEffect } from 'react';
import axios from "axios";
import DropDown from './DropDown';
import "./RewardPoints.css";


const RewardPoints = () => {
    const [price, setprice] = useState(null);
    const [rewardPoints, setRewardPoints] = useState(null);
    const [points, setPoints] = useState({firstmonthreward:null,secondmonthreward:null,thirdmonthreward:null,totalreward:null});
    const [monthOne, setMonthOne] = useState(null);
    const [monthTwo, setMonthTwo] = useState(null);
    const [monthThree, setMonthThree] = useState(null);
    const productName = 'Chimney';

    const getPointsCount = () => {
        const baseURL = `http://localhost:5021/Rewards?month1=${monthOne}&month2=${monthTwo}&month3=${monthThree}`;
       
        axios
            .get(baseURL)
            .then((response) => {
                setPoints(response.data)
            });
    }
    const handlePrice = (e) => {
        let value = e.target.value;
        let difference;
        let rewardPoints;
        setprice(e.target.value);
        if (value && value > 50) {
            if (value < 100 && value > 50) {
                difference = value - 50;
                rewardPoints = difference * 1;
            } else if (value > 100) {
                difference = value - 100;
                rewardPoints = (difference * 2) + (50 * 1);
            }
            setRewardPoints(rewardPoints);
        } else {
            return false;
        }
    }
    const handleDropDown = (e) => {
        const {id,value}=e.target;
        if(id==="monthOne"){
            setMonthOne(value)
        }else if(id==="monthTwo"){
            setMonthTwo(value);
        }else {
            setMonthThree(value);
        }
    }
    const disableButton = !(monthOne && monthTwo && monthThree && monthOne !== "Select a Value" && monthTwo !== "Select a Value" && monthThree !== "Select a Value");
    const {firstmonthreward,secondmonthreward,thirdmonthreward,totalreward}=points;    
    return (
        <div className="page-container">
            <div className='fields-wrapper'>
               
                <div className='dflex mbottom'>
                    <span className='w-50p label'>Purchased item reward Points:</span>
                    <span className='w-50p mleft'>{rewardPoints}</span>
                </div>
                <DropDown id="monthOne" label="Select first month" value={monthOne} defaultValue="Select a month" handleChange={handleDropDown} />
                <DropDown id="monthTwo" label="Select second month" value={monthTwo} defaultValue="Select a month" handleChange={handleDropDown} />
                <DropDown id="monthThree" label="Select third month" value={monthThree} defaultValue="Select a month" handleChange={handleDropDown} />
                <button className="margin-5" onClick={getPointsCount} disableButton={disableButton}>
                    Get Reward Points Count
                </button>
                {points && <div className='dflex mbottom'>
                    <span className='w-50p label'>Three months reward Points:</span>
                    <span className='w-50p mleft'>{totalreward}</span>
                </div>}
                <p>First month reward points: {firstmonthreward} </p>
                <p>Second month reward points: {secondmonthreward} </p>
                <p>Third month reward points: {thirdmonthreward} </p>
            </div>
        </div>
    );
}

export default RewardPoints;