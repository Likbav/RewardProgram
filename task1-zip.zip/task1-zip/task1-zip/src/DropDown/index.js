import React from 'react';

const DropDown = ({ value, defaultValue, handleChange, id,label }) => {
const options = [{
    id: '1',
    value:'january',
    label: 'january',
},
{
    id: '2',
    value:'february',
    label: 'february',
},
{
    id: '3',
    value:'march',
    label: 'march',
},
{
    id: '4',
    value:'april',
    label: 'april',
},
{
    id: '5',
    value:'may',
    label: 'may',
},
{
    id: '6',
    value:'june',
    label: 'june',
},
{
    id: '7',
    value:'july',
    label: 'july',
},
{
    id: '8',
    value:'august',
    label: 'august',
},
{
    id: '9',
    value:'september',
    label: 'september',
},
{
    id: '10',
    value:'october',
    label: 'october',
},
{
    id: '11',
    value:'november',
    label: 'november',
},
{
    id: '12',
    value:'december',
    label: 'december',
}]
    return (
        <div style={{display:"flex",marginBottom:"2%"}}>
            <div>{label}:</div>
            <div style ={{marginLeft:"5%"}}><select
                id={id}
                value={value}
                defaultValue={defaultValue}
                onChange={handleChange}
            >
                <option value="Select a Value">Select a Value</option>
                {options.map((option) => {
                    return <option value={option.value}>{option.label}</option>
                })}
            </select></div>
            
        </div>
    );
}

export default DropDown;