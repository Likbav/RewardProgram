﻿namespace RewardProgram1
{
    public class reward
    {
        public float firstmonthreward { get; set; }
        public float secondmonthreward { get; set; }
        public float thirdmonthreward { get; set; }
        public float totalreward { get; set; }
    }
}
