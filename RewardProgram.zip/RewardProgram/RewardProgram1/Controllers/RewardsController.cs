﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Net;
using System.Reflection.PortableExecutable;
using System.Text.Json;
using System.Xml.Linq;

namespace RewardProgram1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RewardsController : Controller
    {
        [HttpGet]
        public IActionResult Index(string month1,string month2,string month3)
        {
            SqlDataReader reader;
            float temp1 = 0, temp2 = 0, temp3 = 0;
            float rewardformonth1 = 0;
            float rewardformonth2 = 0;
            float rewardformonth3 = 0;
            float summatedvalue = 0;
            using (SqlConnection con = new SqlConnection("data source=servername;initial catalog=rewardprogram;integrated security=true")) 
            {
                con.Open();
                
                string month = "";
                for (int i = 0; i <= 2; i++)
                {
                    summatedvalue = 0;
                    if (i==0)
                    {
                        month = month1;
                    }
                    else if(i == 1)
                    {
                        month = month2;
                    }
                    else if (i == 2)
                    {
                        month = month3;
                    }
                    
                    SqlCommand cmd = new SqlCommand("select amount from transactions where month='"+month+"'",con);
                    reader = cmd.ExecuteReader();

                    while(reader.Read())
                    {
                        temp1 = float.Parse(reader["amount"].ToString());
                        //business logic goes here
                        if(temp1>100)
                        {
                            temp2 = temp1 - 100;
                        }
                        else
                        {
                            temp2 = 0;
                        }
                        temp2 = 2 * temp2;
                        if(temp1>50 && temp1<=100)
                        {
                            temp3 = temp1 - 50;
                        }
                        else if(temp1>100)
                        {
                            temp3 = 50;
                        }
                        else
                        {
                            temp3 = 0;
                        }
                        summatedvalue += temp2 + temp3;
                    }
                    reader.Close();
                    if(i==0)
                    {
                        rewardformonth1 = summatedvalue;

                    }
                    else if (i == 1)
                    {
                        rewardformonth2 = summatedvalue;

                    }
                    else
                    {
                        rewardformonth3 = summatedvalue;
                    }
                }
            }

            reward obj = new reward();
            obj.firstmonthreward = rewardformonth1;
            obj.secondmonthreward = rewardformonth2;
            obj.thirdmonthreward = rewardformonth3;
            obj.totalreward = rewardformonth1 + rewardformonth2 + rewardformonth3;
            return Ok(obj);
        }
    }
}

